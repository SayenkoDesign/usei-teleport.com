<section  class="section-parallax" data-stellar-background-ratio="0.1" data-stellar-vertical-offset="1">
    	<div class="white-shape leftalign"></div>
    	<div class="parallax-wrapper">
        	<div class="container">
            	<div class="video-play text-center">
                    <a data-gal="prettyPhoto" rel="bookmark" href="<?php echo $instance['video_url'];?>"><i class="icon icon-Play"></i></a>
                </div>
        	</div><!-- end container -->
		</div><!-- end section-container -->
    </section><!-- end section -->
