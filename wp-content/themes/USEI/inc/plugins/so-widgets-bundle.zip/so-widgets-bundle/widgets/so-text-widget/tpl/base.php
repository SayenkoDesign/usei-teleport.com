<div class="text-<?php echo $instance['align'];?>">
    <div class="makepadding">
        <h3><?php echo $instance['text'];?></h3>
        <p class="lead"><?php echo $instance['description'];?></p>
    </div>
</div>
